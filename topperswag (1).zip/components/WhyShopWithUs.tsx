
import React from 'react';
import { TruckIcon } from './icons/TruckIcon';
import { CheckBadgeIcon } from './icons/CheckBadgeIcon';
import { SparklesIcon } from './icons/SparklesIcon';

const FeatureCard: React.FC<{ title: string; description: string; icon: React.ReactNode }> = ({ title, description, icon }) => (
  <div className="flex flex-col items-center text-center p-4 sm:p-6 bg-base-100 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
    <div className="p-3 sm:p-4 bg-brand-secondary rounded-full text-brand-primary mb-3 sm:mb-4 inline-block">
      {icon}
    </div>
    <h3 className="text-lg sm:text-xl font-semibold text-neutral mb-2">{title}</h3>
    <p className="text-gray-600 text-sm sm:text-base">{description}</p>
  </div>
);

export const WhyShopWithUs: React.FC = () => {
  const features = [
    {
      title: 'Blazing Fast Shipping',
      description: 'Get your swag delivered quickly across India. We know you can\'t wait!',
      icon: <TruckIcon className="w-7 h-7 sm:w-8 sm:h-8" />
    },
    {
      title: 'Premium Quality Gear',
      description: 'Top-notch materials and prints that last. Look good, feel good, ace that test.',
      icon: <CheckBadgeIcon className="w-7 h-7 sm:w-8 sm:h-8" />
    },
    {
      title: 'Fresh Gen Z Designs',
      description: 'Designs that speak your language. Trendy, witty, and totally you.',
      icon: <SparklesIcon className="w-7 h-7 sm:w-8 sm:h-8" />
    }
  ];

  return (
    <section className="py-10 sm:py-12 bg-base-200">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-center text-neutral mb-8 sm:mb-10">Why TopperSwag?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {features.map(feature => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </div>
    </section>
  );
};
