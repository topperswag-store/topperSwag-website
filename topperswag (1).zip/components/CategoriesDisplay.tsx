
import React from 'react';
import { CATEGORIES } from '../constants'; 
import { Category } from '../types';

interface CategoriesDisplayProps {
  onNavigate: (page: string, categorySlug?: string) => void;
}

export const CategoriesDisplay: React.FC<CategoriesDisplayProps> = ({ onNavigate }) => {
  return (
    <section className="py-10 sm:py-12 bg-base-100">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-center text-neutral mb-8 sm:mb-10">Shop by Category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
          {CATEGORIES.map((category: Category) => (
            <button
              key={category.slug}
              onClick={() => onNavigate('shop', category.slug)}
              className="group relative rounded-lg overflow-hidden shadow-md hover:shadow-xl transform transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-opacity-50"
              aria-label={`Shop ${category.name}`}
            >
              <img 
                src={category.imageUrl || `https://via.placeholder.com/400x300?text=${category.name}`} 
                alt={category.name} 
                className="w-full h-36 sm:h-48 object-cover transition-transform duration-500 group-hover:scale-110" 
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 group-hover:bg-opacity-30 transition-opacity duration-300 flex items-center justify-center p-2">
                <h3 className="text-white text-base sm:text-xl lg:text-2xl font-semibold text-center leading-tight">{category.name}</h3>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
