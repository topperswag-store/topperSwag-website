
import React from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface ProductListProps {
  products: Product[];
  onAddToCart: (product: Product, quantity?: number) => void;
  onBuyNow: (product: Product, quantity?: number) => void;
  onProductClick: (productId: string) => void; // New prop
}

export const ProductList: React.FC<ProductListProps> = ({ products, onAddToCart, onBuyNow, onProductClick }) => {
  if (!products.length) {
    return (
      <div className="text-center py-10 min-h-[200px] flex flex-col justify-center items-center">
        <h2 className="text-xl font-semibold text-neutral mb-2">No products to display currently.</h2>
        <p className="text-gray-500">Please check back later or try a different filter.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
      {products.map(product => (
        <ProductCard 
            key={product.id} 
            product={product} 
            onAddToCart={onAddToCart}
            onBuyNow={onBuyNow}
            onProductClick={onProductClick} // Pass down
        />
      ))}
    </div>
  );
};
