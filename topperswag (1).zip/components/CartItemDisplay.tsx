
import React from 'react';
import { CartItem } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';
import { MinusIcon } from './icons/MinusIcon';

interface CartItemDisplayProps {
  item: CartItem;
  onIncrement: (productId: string) => void;
  onDecrement: (productId: string) => void;
  onRemove: (productId: string) => void;
}

export const CartItemDisplay: React.FC<CartItemDisplayProps> = ({ item, onIncrement, onDecrement, onRemove }) => {
  return (
    <div className="flex items-center p-3 bg-white rounded-lg shadow space-x-3 sm:space-x-4 border border-base-200">
      <img 
        src={item.imageUrl || 'https://via.placeholder.com/80?text=No+Image'} 
        alt={item.name} 
        className="w-16 h-16 sm:w-20 sm:h-20 rounded-md object-cover flex-shrink-0" 
      />
      <div className="flex-grow min-w-0">
        <h4 className="text-sm sm:text-base font-semibold text-neutral truncate" title={item.name}>{item.name}</h4>
        <p className="text-xs text-gray-500 mb-1">Category: {item.category}</p>
        <p className="text-sm sm:text-base font-medium text-brand-primary">₹{item.price.toFixed(2)}</p>
      </div>
      <div className="flex flex-col items-end space-y-1 sm:space-y-2 flex-shrink-0">
        <div className="flex items-center border border-gray-300 rounded">
          <button 
            onClick={() => onDecrement(item.id)}
            className="p-1 sm:p-1.5 text-gray-600 hover:bg-gray-100 disabled:opacity-50"
            aria-label={`Decrease quantity of ${item.name}`}
            disabled={item.quantity <= 1}
          >
            <MinusIcon className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
          <span className="px-2 sm:px-3 text-sm sm:text-base font-medium text-neutral w-8 text-center">{item.quantity}</span>
          <button 
            onClick={() => onIncrement(item.id)}
            className="p-1 sm:p-1.5 text-gray-600 hover:bg-gray-100"
            aria-label={`Increase quantity of ${item.name}`}
          >
            <PlusIcon className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
        <button 
          onClick={() => onRemove(item.id)}
          className="text-red-500 hover:text-red-700 p-1 text-xs flex items-center"
          aria-label={`Remove ${item.name} from cart`}
        >
          <TrashIcon className="w-4 h-4 mr-1" /> Remove
        </button>
      </div>
    </div>
  );
};
