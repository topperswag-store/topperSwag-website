import React from 'react';
import { InstagramIcon } from './icons/InstagramIcon';
import { MailIcon } from './icons/MailIcon'; 

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    { name: 'About Us', page: 'about' },
    { name: 'Contact Us', page: 'contact' },
    { name: 'Track Order', page: 'track-order' },
  ];

  const policyLinks = [
    { name: 'Return & Refund Policy', page: 'refund-policy' },
    { name: 'Privacy Policy', page: 'privacy-policy' },
    { name: 'Terms & Conditions', page: 'terms-conditions' },
  ];

  return (
    <footer className="bg-brand-primary text-gray-300 py-10 sm:py-12 mt-12 sm:mt-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Column 1: Brand and Social */}
          <div className="sm:col-span-2 lg:col-span-1">
            <h3 className="text-xl font-bold text-white mb-3 cursor-pointer" onClick={() => onNavigate('home')}>
                Topper<span className="text-brand-secondary">Swag</span>
            </h3>
            <p className="text-sm mb-4">India’s #1 Student-Focused Online Store. Trendy gear for Gen Z.</p>
            <div className="flex space-x-4">
              <a href="https://instagram.com/topper.swag" target="_blank" rel="noopener noreferrer" aria-label="TopperSwag on Instagram" className="text-gray-300 hover:text-brand-secondary transition-colors">
                <InstagramIcon className="w-6 h-6" />
              </a>
              <a href="mailto:topperswag@gmail.com" aria-label="Email TopperSwag" className="text-gray-300 hover:text-brand-secondary transition-colors">
                <MailIcon className="w-6 h-6" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-base font-semibold text-white mb-3 uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2">
              {footerLinks.map(link => (
                <li key={link.page}>
                  <button onClick={() => onNavigate(link.page)} className="hover:text-brand-secondary transition-colors text-sm">{link.name}</button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Policies */}
          <div>
            <h4 className="text-base font-semibold text-white mb-3 uppercase tracking-wider">Information</h4>
            <ul className="space-y-2">
              {policyLinks.map(link => (
                <li key={link.page}>
                  <button onClick={() => onNavigate(link.page)} className="hover:text-brand-secondary transition-colors text-sm">{link.name}</button>
                </li>
              ))}
               <li> {/* Admin Panel Link */}
                  <button onClick={() => onNavigate('admin')} className="hover:text-brand-secondary transition-colors text-sm">Admin Panel</button>
              </li>
            </ul>
          </div>
          
          {/* Column 4: Newsletter (Placeholder) */}
          <div className="lg:col-span-1">
             <h4 className="text-base font-semibold text-white mb-3 uppercase tracking-wider">Stay Updated</h4>
             <p className="text-sm mb-3">Get a sneak peek at new arrivals & exclusive offers!</p>
             <form onSubmit={(e) => { e.preventDefault(); alert('Newsletter signup coming soon!'); }}>
                 <input type="email" placeholder="Enter your email" className="w-full p-2 rounded-md bg-brand-primary-focus text-white placeholder-gray-400 text-sm focus:ring-2 focus:ring-brand-secondary focus:outline-none" />
                 <button type="submit" className="w-full mt-2 bg-brand-secondary text-brand-primary font-semibold py-2 px-4 rounded-md text-sm hover:bg-brand-secondary-focus transition-colors">
                     Subscribe
                 </button>
             </form>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-center">
          <div className="mb-3 text-xs sm:text-sm space-x-2 sm:space-x-4">
            <span className="font-semibold">Secure Payments</span>
            <span className="text-gray-500">|</span>
            <span className="font-semibold">Easy Returns</span>
            <span className="text-gray-500">|</span>
            <span className="font-semibold">Gen Z Approved</span>
          </div>
          <p className="text-sm">&copy; {currentYear} TopperSwag. All rights reserved.</p>
          <p className="text-xs mt-1">Fuel Your Ambition. Wear Your Success.</p>
        </div>
      </div>
    </footer>
  );
};