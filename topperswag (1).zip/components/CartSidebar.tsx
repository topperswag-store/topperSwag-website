
import React from 'react';
import { CartItem } from '../types';
import { XIcon } from './icons/XIcon';
import { CartItemDisplay } from './CartItemDisplay';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onIncrement: (productId: string) => void;
  onDecrement: (productId: string) => void;
  onRemove: (productId: string) => void;
  onClearCart: () => void;
  subtotal: number;
  onNavigate: (page: string, slug?: string) => void;
  onCheckout: () => void; // New prop for checkout action
}

export const CartSidebar: React.FC<CartSidebarProps> = ({
  isOpen,
  onClose,
  cartItems,
  onIncrement,
  onDecrement,
  onRemove,
  onClearCart,
  subtotal,
  onNavigate,
  onCheckout, // Use this prop
}) => {
  if (!isOpen) return null;

  const handleShopNow = () => {
    onNavigate('shop');
    onClose();
  }

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-[90] transition-opacity duration-300 ease-in-out"
        onClick={onClose}
        aria-hidden="true"
      ></div>

      {/* Sidebar */}
      <aside 
        className={`fixed top-0 right-0 w-full sm:w-96 md:w-[400px] h-full bg-base-100 shadow-2xl z-[100] transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'} flex flex-col`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-sidebar-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-base-300">
          <h2 id="cart-sidebar-title" className="text-xl font-semibold text-brand-primary">Your Cart</h2>
          <button 
            onClick={onClose} 
            className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-base-200"
            aria-label="Close cart sidebar"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>

        {/* Cart Items */}
        {cartItems.length === 0 ? (
          <div className="flex-grow flex flex-col items-center justify-center p-6 text-center">
            <img src="https://via.placeholder.com/150/E5E7EB/808080?text=Empty+Cart" alt="Empty Cart" className="w-32 h-32 mb-4 opacity-50"/>
            <p className="text-lg font-medium text-neutral mb-2">Your cart is empty!</p>
            <p className="text-sm text-gray-500 mb-6">Looks like you haven't added anything to your cart yet.</p>
            <button
              onClick={handleShopNow}
              className="bg-brand-primary text-white font-semibold py-2.5 px-6 rounded-lg hover:bg-brand-primary-focus transition-colors"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          <div className="flex-grow overflow-y-auto p-4 sm:p-5 space-y-4">
            {cartItems.map(item => (
              <CartItemDisplay 
                key={item.id}
                item={item}
                onIncrement={onIncrement}
                onDecrement={onDecrement}
                onRemove={onRemove}
              />
            ))}
          </div>
        )}

        {/* Footer */}
        {cartItems.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-base-300 mt-auto">
            <div className="flex justify-between items-center mb-3">
              <span className="text-lg font-semibold text-neutral">Subtotal:</span>
              <span className="text-xl font-bold text-brand-primary">₹{subtotal.toFixed(2)}</span>
            </div>
            <p className="text-xs text-gray-500 mb-4 text-center">Shipping & taxes calculated at checkout.</p>
            <button
              onClick={onCheckout} // Use the passed onCheckout prop
              className="w-full bg-brand-secondary text-brand-primary font-bold py-3 px-4 rounded-lg text-base hover:bg-brand-secondary-focus transition-colors mb-2"
            >
              Proceed to Checkout
            </button>
            <button
              onClick={onClearCart}
              className="w-full bg-gray-200 text-gray-700 font-medium py-2.5 px-4 rounded-lg text-sm hover:bg-gray-300 transition-colors"
            >
              Clear Cart
            </button>
          </div>
        )}
      </aside>
    </>
  );
};
