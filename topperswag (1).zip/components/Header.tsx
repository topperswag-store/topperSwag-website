
import React, { useState } from 'react';
import { ShoppingCartIcon } from './icons/ShoppingCartIcon';
import { SearchIcon } from './icons/SearchIcon';
import { MenuIcon } from './icons/MenuIcon'; 
import { XIcon } from './icons/XIcon'; 

interface HeaderProps {
  onSearch: (searchTerm: string) => void;
  cartItemCount: number;
  onNavigate: (page: string) => void;
  currentPage: string;
  onToggleCart: () => void; // New prop
}

export const Header: React.FC<HeaderProps> = ({ onSearch, cartItemCount, onNavigate, currentPage, onToggleCart }) => {
  const [inputValue, setInputValue] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSearch(inputValue);
    setMobileMenuOpen(false); 
  };

  const navLinks = [
    { name: 'Home', page: 'home' },
    { name: 'Shop', page: 'shop' },
    { name: 'About Us', page: 'about' },
    { name: 'Contact Us', page: 'contact' },
    { name: 'Track Order', page: 'track-order' },
  ];

  const NavLinkItem: React.FC<{name: string, page: string, isMobile?: boolean}> = ({ name, page, isMobile}) => (
    <button
      onClick={() => { onNavigate(page); if(isMobile) setMobileMenuOpen(false); }}
      className={`w-full text-left md:w-auto md:text-center px-3 py-2 rounded-md text-sm font-medium transition-colors duration-150
        ${currentPage === page 
          ? 'bg-brand-secondary text-brand-primary' 
          : 'text-white hover:bg-brand-primary-focus hover:text-brand-secondary'
        }`}
      aria-current={currentPage === page ? "page" : undefined}
    >
      {name}
    </button>
  );

  return (
    <header className="bg-brand-primary text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <button onClick={() => onNavigate('home')} className="text-2xl sm:text-3xl font-bold tracking-tight hover:opacity-80 transition-opacity">
            Topper<span className="text-brand-secondary">Swag</span>
          </button>
          
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navLinks.map(link => <NavLinkItem key={link.page} {...link} />)}
          </nav>

          <div className="flex items-center space-x-2 sm:space-x-4">
            <form onSubmit={handleSubmit} className="relative hidden sm:block">
              <input
                type="text"
                placeholder="Search..."
                value={inputValue}
                onChange={handleInputChange}
                className="py-2 px-3 sm:px-4 pr-10 rounded-full bg-white bg-opacity-20 placeholder-gray-300 text-white focus:bg-opacity-30 focus:outline-none focus:ring-2 focus:ring-brand-secondary transition-all w-32 md:w-40 lg:w-56 text-sm"
                aria-label="Search products"
              />
              <button type="submit" className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2 text-gray-300 hover:text-white" aria-label="Submit search">
                <SearchIcon className="w-5 h-5" />
              </button>
            </form>
            <div 
              className="relative cursor-pointer group" 
              onClick={onToggleCart} // Updated onClick
              role="button" 
              aria-label={`View shopping cart, ${cartItemCount} items`}
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onToggleCart();}}
            >
              <ShoppingCartIcon className="w-6 h-6 sm:w-7 sm:h-7 text-white group-hover:text-brand-secondary transition-colors" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </div>
            <div className="md:hidden">
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-white p-1 hover:text-brand-secondary focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-secondary" aria-label="Toggle navigation menu" aria-expanded={mobileMenuOpen}>
                {mobileMenuOpen ? <XIcon className="w-6 h-6 sm:w-7 sm:h-7" /> : <MenuIcon className="w-6 h-6 sm:w-7 sm:h-7" />}
              </button>
            </div>
          </div>
        </div>
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-brand-primary-focus">
            <nav className="flex flex-col space-y-1 px-2 py-3">
              {navLinks.map(link => <NavLinkItem key={link.page} {...link} isMobile={true} />)}
               <form onSubmit={handleSubmit} className="relative mt-2 sm:hidden">
                <input
                  type="text"
                  placeholder="Search products..."
                  value={inputValue}
                  onChange={handleInputChange}
                  className="w-full py-2 px-4 pr-10 rounded-full bg-white bg-opacity-20 placeholder-gray-300 text-white focus:bg-opacity-30 focus:outline-none focus:ring-2 focus:ring-brand-secondary transition-all text-sm"
                  aria-label="Search products mobile"
                />
                <button type="submit" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-300 hover:text-white" aria-label="Submit search mobile">
                  <SearchIcon className="w-5 h-5" />
                </button>
              </form>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};
