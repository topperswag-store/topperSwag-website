
import React from 'react';

interface HeroBannerProps {
  onShopNow: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onShopNow }) => {
  return (
    <div className="bg-gradient-to-br from-brand-primary via-neutral to-brand-primary text-white py-16 md:py-24 lg:py-32 px-4">
      <div className="container mx-auto text-center">
        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold mb-3 sm:mb-4 leading-tight">
          Fuel Your Ambition.
        </h1>
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 sm:mb-8 leading-tight">
          Wear Your <span className="text-brand-secondary">Success</span>.
        </h2>
        <p className="text-base sm:text-lg md:text-xl text-gray-200 mb-8 sm:mb-10 max-w-md md:max-w-2xl mx-auto">
          Discover trendy t-shirts, hoodies, accessories, and motivation gear designed exclusively for Gen Z students in India.
        </p>
        <button
          onClick={onShopNow}
          className="bg-brand-secondary text-brand-primary font-bold py-3 px-8 sm:px-10 rounded-lg text-base sm:text-lg hover:bg-brand-secondary-focus focus:outline-none focus:ring-4 focus:ring-brand-secondary focus:ring-opacity-50 transition-all duration-300 transform hover:scale-105"
        >
          Shop Now & Unleash Your Swag!
        </button>
      </div>
    </div>
  );
};
