import React, { useState, useEffect } from 'react';
import { Product, ProductFormValues } from '../types';

interface ProductFormProps {
  initialValues?: Product | null;
  onSubmit: (productData: ProductFormValues) => void;
  onCancel: () => void;
}

export const ProductForm: React.FC<ProductFormProps> = ({ initialValues, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState<ProductFormValues>({
    id: undefined,
    name: '',
    description: '',
    price: '',
    imageUrl: '',
    category: '',
    stock: '',
    rating: '',
    tags: '',
  });

  useEffect(() => {
    if (initialValues) {
      setFormData({
        id: initialValues.id,
        name: initialValues.name,
        description: initialValues.description,
        price: initialValues.price.toString(),
        imageUrl: initialValues.imageUrl,
        category: initialValues.category,
        stock: initialValues.stock?.toString() || '',
        rating: initialValues.rating?.toString() || '',
        tags: initialValues.tags?.join(', ') || '',
      });
    } else {
      // Reset form for adding new product or if initialValues becomes null
      setFormData({
        id: undefined,
        name: '',
        description: '',
        price: '',
        imageUrl: '',
        category: '',
        stock: '',
        rating: '',
        tags: '',
      });
    }
  }, [initialValues]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const formFields: { name: keyof ProductFormValues; label: string; type: string; required?: boolean, placeholder?: string, rows?: number }[] = [
    { name: 'name', label: 'Product Name', type: 'text', required: true, placeholder: 'e.g., Awesome T-Shirt' },
    { name: 'description', label: 'Description', type: 'textarea', required: true, placeholder: 'Detailed product description', rows: 3 },
    { name: 'price', label: 'Price (INR)', type: 'number', required: true, placeholder: 'e.g., 699' },
    { name: 'imageUrl', label: 'Image URL', type: 'url', required: true, placeholder: 'https://example.com/image.jpg' },
    { name: 'category', label: 'Category', type: 'text', required: true, placeholder: 'e.g., T-Shirts, Hoodies' },
    { name: 'stock', label: 'Stock Quantity', type: 'number', placeholder: 'e.g., 50 (0 for out of stock)' },
    { name: 'rating', label: 'Rating (0-5)', type: 'number', placeholder: 'e.g., 4.5 (optional)' },
    { name: 'tags', label: 'Tags (comma-separated)', type: 'text', placeholder: 'e.g., Student Special, New Arrival' },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {formFields.map(field => (
        <div key={field.name}>
          <label htmlFor={field.name} className="block text-sm font-medium text-gray-700 mb-1">
            {field.label} {field.required && <span className="text-red-500">*</span>}
          </label>
          {field.type === 'textarea' ? (
            <textarea
              id={field.name}
              name={field.name}
              value={formData[field.name] as string || ''}
              onChange={handleChange}
              required={field.required}
              placeholder={field.placeholder}
              rows={field.rows || 3}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm"
            />
          ) : (
            <input
              id={field.name}
              name={field.name}
              type={field.type}
              value={formData[field.name] as string || ''}
              onChange={handleChange}
              required={field.required}
              placeholder={field.placeholder}
              min={field.type === 'number' ? '0' : undefined}
              step={field.name === 'price' || field.name === 'rating' ? '0.01' : '1'}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm"
            />
          )}
        </div>
      ))}
      <div className="flex justify-end space-x-3 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-base-200 rounded-md hover:bg-base-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-brand-primary rounded-md hover:bg-brand-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary"
        >
          {initialValues ? 'Save Changes' : 'Add Product'}
        </button>
      </div>
    </form>
  );
};