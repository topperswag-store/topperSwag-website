
import React from 'react';
import { Product } from '../types';
import { StarIcon } from './icons/StarIcon';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, quantity?: number) => void;
  onBuyNow: (product: Product, quantity?: number) => void;
  onProductClick: (productId: string) => void; // New prop
}

const renderStars = (rating?: number) => {
  if (typeof rating !== 'number' || rating < 0 || rating > 5) {
    return <div className="h-5 mb-1"></div>; 
  }
  const fullStars = Math.floor(rating);
  const halfStarThreshold = 0.25; 
  const nearlyFullStarThreshold = 0.75;
  
  let effectiveFullStars = fullStars;
  let hasHalfStar = false;

  const decimalPart = rating % 1;

  if (decimalPart >= nearlyFullStarThreshold) {
    effectiveFullStars += 1;
  } else if (decimalPart >= halfStarThreshold) {
    hasHalfStar = true;
  }
  
  const emptyStars = 5 - effectiveFullStars - (hasHalfStar ? 1 : 0);
  
  return (
    <div className="flex items-center mb-1" aria-label={`Rating: ${rating.toFixed(1)} out of 5 stars`}>
      {[...Array(effectiveFullStars)].map((_, i) => (
        <StarIcon key={`full-${i}`} className="w-5 h-5 text-yellow-400" filled={true} aria-hidden="true" />
      ))}
      {hasHalfStar && <StarIcon key="half" className="w-5 h-5 text-yellow-400" filled={true} isHalf={true} aria-hidden="true" />}
      {[...Array(Math.max(0, emptyStars))].map((_, i) => ( 
        <StarIcon key={`empty-${i}`} className="w-5 h-5 text-gray-300" filled={false} aria-hidden="true" />
      ))}
      <span className="ml-2 text-xs sm:text-sm text-gray-500">({rating.toFixed(1)})</span>
    </div>
  );
};

export const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onBuyNow, onProductClick }) => {
  const isOutOfStock = product.stock !== undefined && product.stock <= 0;

  const handleCardClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Prevent navigation if click is on a button
    if ((e.target as HTMLElement).closest('button')) {
      return;
    }
    onProductClick(product.id);
  };
  
  const handleCardKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
       if ((e.target as HTMLElement).closest('button')) {
        return;
      }
      onProductClick(product.id);
    }
  };


  return (
    <div 
      className="bg-base-100 rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1 flex flex-col h-full group cursor-pointer"
      onClick={handleCardClick}
      onKeyDown={handleCardKeyDown}
      role="link" // Semantically it acts as a link
      tabIndex={0} // Make it focusable
      aria-label={`View details for ${product.name}`}
    >
      <div className="relative w-full aspect-[3/4] sm:aspect-square md:aspect-[3/4] overflow-hidden">
        <img 
          src={product.imageUrl || 'https://via.placeholder.com/600x800?text=No+Image'} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute top-2 left-2 sm:top-3 sm:left-3 space-y-1 sm:space-y-2">
          {product.tags?.map(tag => (
            <span key={tag} className={`text-[10px] sm:text-xs font-semibold px-1.5 py-0.5 sm:px-2 sm:py-1 rounded
              ${tag.toLowerCase().includes('special') || tag.toLowerCase().includes('new') 
                ? 'bg-brand-secondary text-brand-primary' 
                : tag.toLowerCase().includes('best seller')
                ? 'bg-yellow-400 text-neutral'
                : 'bg-brand-accent text-white'}`}>
              {tag}
            </span>
          ))}
        </div>
         {isOutOfStock && (
           <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center">
             <span className="text-white text-base sm:text-lg font-semibold px-2 text-center">Out of Stock</span>
           </div>
         )}
      </div>
      <div className="p-3 sm:p-5 flex flex-col flex-grow">
        <h3 className="text-base sm:text-lg font-semibold text-neutral mb-1 truncate" title={product.name}>
          {product.name}
        </h3>
        <p className="text-xs sm:text-sm text-gray-500 mb-1 sm:mb-2">{product.category}</p>
        {renderStars(product.rating)}
        <p className="text-gray-600 text-xs sm:text-sm mb-2 sm:mb-3 flex-grow line-clamp-2 sm:line-clamp-3">
          {product.description}
        </p>
        
        <div className="mt-auto">
          <p className="text-xl sm:text-2xl font-bold text-brand-primary mb-2 sm:mb-3">
            ₹{product.price.toFixed(2)}
          </p>
          <div className="space-y-2">
            <button 
              onClick={(e) => { e.stopPropagation(); onAddToCart(product); }}
              disabled={isOutOfStock}
              className="w-full bg-brand-primary text-white px-3 py-2 sm:px-5 sm:py-2.5 rounded-lg text-sm sm:text-base font-medium hover:bg-brand-primary-focus focus:outline-none focus:ring-2 focus:ring-brand-primary-focus focus:ring-opacity-50 transition-colors duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed"
              aria-label={`Add ${product.name} to cart`}
            >
              Add to Cart
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onBuyNow(product); }}
              disabled={isOutOfStock}
              className="w-full bg-brand-secondary text-brand-primary px-3 py-2 sm:px-5 sm:py-2.5 rounded-lg text-sm sm:text-base font-semibold hover:bg-brand-secondary-focus focus:outline-none focus:ring-2 focus:ring-brand-secondary-focus focus:ring-opacity-50 transition-colors duration-300 disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed"
              aria-label={`Buy ${product.name} now`}
            >
              Buy Now
            </button>
          </div>
          {product.stock !== undefined && !isOutOfStock && product.stock > 0 && product.stock < 10 && (
            <p className="mt-2 text-xs sm:text-sm text-red-600 font-medium">
              Hurry! Only {product.stock} left.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
