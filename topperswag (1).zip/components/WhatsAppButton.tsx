
import React from 'react';
import { WhatsAppIcon } from './icons/WhatsAppIcon'; 

export const WhatsAppButton: React.FC = () => {
  const whatsappNumber = "91XXXXXXXXXX"; // Replace with your actual WhatsApp business number including country code
  const defaultMessage = "Hello TopperSwag! I have a question about your products.";
  // Ensure the number is digits only for the wa.me link if it includes characters like '+'
  const cleanedWhatsappNumber = whatsappNumber.replace(/\D/g, '');
  const whatsappUrl = `https://wa.me/${cleanedWhatsappNumber}?text=${encodeURIComponent(defaultMessage)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 bg-[#25D366] text-white p-3 sm:p-4 rounded-full shadow-xl hover:bg-[#1DAE52] focus:outline-none focus:ring-2 focus:ring-[#25D366] focus:ring-offset-2 transition-all duration-300 z-40 flex items-center justify-center group"
      aria-label="Chat with TopperSwag on WhatsApp"
    >
      <WhatsAppIcon className="w-7 h-7 sm:w-8 sm:h-8 transition-transform duration-300 group-hover:scale-110" />
    </a>
  );
};
