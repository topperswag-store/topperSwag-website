
import React from 'react';

interface StarIconProps {
  className?: string;
  filled: boolean;
  isHalf?: boolean;
}

export const StarIcon: React.FC<StarIconProps> = ({ className, filled, isHalf }) => {
  const starPath = "M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.82.61l-4.725-2.885a.562.562 0 0 0-.652 0l-4.725 2.885a.562.562 0 0 1-.82-.61l1.285-5.385a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5Z";
  
  if (isHalf && filled) {
    const uniqueClipID = `halfStarClip-${React.useId()}`;
    return (
      <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        className={className || "w-5 h-5"}
        aria-hidden="true"
      >
        <defs>
          <clipPath id={uniqueClipID}>
            <rect x="0" y="0" width="12" height="24" />
          </clipPath>
        </defs>
        {/* Filled half */}
        <path d={starPath} fill="currentColor" clipPath={`url(#${uniqueClipID})`} />
        {/* The other half, empty-like (using a lighter gray or similar) */}
        <path d={starPath} fill="currentColor" className="text-gray-300 opacity-50" style={{ clipPath: 'polygon(50% 0, 100% 0, 100% 100%, 50% 100%)' }} />

      </svg>
    );
  }

  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      className={className || "w-5 h-5"}
      fill={filled ? "currentColor" : "none"}
      stroke={filled ? "none" : "currentColor"} // Only stroke if not filled (for empty star)
      strokeWidth={filled ? 0 : 1.5} // Stroke width for empty star
      aria-hidden="true"
    >
      <path strokeLinecap="round" strokeLinejoin="round" d={starPath} />
    </svg>
  );
};
