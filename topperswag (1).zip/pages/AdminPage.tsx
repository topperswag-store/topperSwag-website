import React, { useState } from 'react';
import { Product, ProductFormValues } from '../types';
import { Modal } from '../components/Modal';
import { ProductForm } from '../components/ProductForm';
import { PencilIcon } from '../components/icons/PencilIcon';
import { TrashIcon } from '../components/icons/TrashIcon';

interface AdminPageProps {
  products: Product[];
  onAddProduct: (productData: ProductFormValues) => void;
  onUpdateProduct: (productData: Product) => void;
  onDeleteProduct: (productId: string) => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ products, onAddProduct, onUpdateProduct, onDeleteProduct }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);


  const handleOpenModalForAdd = () => {
    setEditingProduct(null);
    setIsModalOpen(true);
  };

  const handleOpenModalForEdit = (product: Product) => {
    setEditingProduct(product);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingProduct(null);
  };

  const handleFormSubmit = (productData: ProductFormValues) => {
    const processedData = {
        ...productData,
        price: parseFloat(productData.price) || 0,
        stock: parseInt(productData.stock, 10) || 0,
        rating: parseFloat(productData.rating) || undefined,
        tags: productData.tags ? productData.tags.split(',').map(tag => tag.trim()).filter(Boolean) : [],
    };

    if (editingProduct && editingProduct.id) { // Check if editingProduct and its id exist
      onUpdateProduct({ ...processedData, id: editingProduct.id } as Product);
    } else {
      onAddProduct(productData); // The addProduct in App.tsx handles ID generation and full conversion
    }
    handleCloseModal();
  };

  const handleDeleteClick = (product: Product) => {
    setProductToDelete(product);
    setIsConfirmModalOpen(true);
  };

  const confirmDelete = () => {
    if (productToDelete) {
      onDeleteProduct(productToDelete.id);
    }
    setIsConfirmModalOpen(false);
    setProductToDelete(null);
  };

  return (
    <div className="container mx-auto px-4 py-8 bg-base-100 shadow-lg rounded-lg">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary">Product Management</h1>
        <button
          onClick={handleOpenModalForAdd}
          className="bg-brand-secondary text-brand-primary font-semibold py-2 px-4 rounded-md hover:bg-brand-secondary-focus transition-colors"
        >
          Add New Product
        </button>
      </div>
      
      <p className="mb-4 text-sm text-gray-600">
        Note: Changes made here are for demonstration purposes and will only persist for the current session. Refreshing the page will revert to the initial product list.
      </p>

      {products.length === 0 ? (
        <p className="text-neutral text-center py-5">No products available. Add some!</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {products.map((product) => (
                <tr key={product.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <img src={product.imageUrl || 'https://via.placeholder.com/50'} alt={product.name} className="w-10 h-10 rounded-md object-cover"/>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{product.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{product.category}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">₹{product.price.toFixed(2)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${product.stock && product.stock > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {product.stock && product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button onClick={() => handleOpenModalForEdit(product)} className="text-brand-accent hover:text-brand-accent-focus p-1" aria-label={`Edit ${product.name}`}>
                        <PencilIcon className="w-5 h-5"/>
                    </button>
                    <button onClick={() => handleDeleteClick(product)} className="text-red-600 hover:text-red-800 p-1" aria-label={`Delete ${product.name}`}>
                        <TrashIcon className="w-5 h-5"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingProduct ? 'Edit Product' : 'Add New Product'}>
        <ProductForm 
          initialValues={editingProduct} 
          onSubmit={handleFormSubmit}
          onCancel={handleCloseModal}
        />
      </Modal>

      <Modal isOpen={isConfirmModalOpen} onClose={() => setIsConfirmModalOpen(false)} title="Confirm Deletion">
          <div className="text-center">
            <p className="mb-4 text-neutral">Are you sure you want to delete the product "{productToDelete?.name}"?</p>
            <div className="flex justify-center space-x-3">
              <button
                onClick={() => setIsConfirmModalOpen(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-base-200 rounded-md hover:bg-base-300"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
      </Modal>

    </div>
  );
};