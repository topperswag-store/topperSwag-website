
import React, { useState } from 'react';

interface TrackingInfo {
  status: string;
  lastUpdate: string;
  estimatedDelivery?: string;
  details: string[];
}

export const TrackOrderPage: React.FC = () => {
  const [orderId, setOrderId] = useState('');
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [trackingInfo, setTrackingInfo] = useState<TrackingInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!orderId || !emailOrPhone) {
      setError("Please enter both Order ID and Email/Phone.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setTrackingInfo(null);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mock responses
    if (orderId === "TS12345" && emailOrPhone.includes("test")) {
      setTrackingInfo({
        status: "Shipped",
        lastUpdate: "October 26, 2023, 10:00 AM",
        estimatedDelivery: "October 28, 2023",
        details: [
          "October 26, 2023, 10:00 AM: Package picked up by courier.",
          "October 25, 2023, 02:30 PM: Order processed and ready for shipment.",
          "October 25, 2023, 09:15 AM: Order confirmed."
        ]
      });
    } else if (orderId === "TS67890") {
        setTrackingInfo({
        status: "Delivered",
        lastUpdate: "October 24, 2023, 03:00 PM",
        details: [
          "October 24, 2023, 03:00 PM: Delivered successfully.",
          "October 24, 2023, 09:00 AM: Out for delivery.",
          "October 23, 2023, 05:00 PM: Arrived at local delivery hub."
        ]
      });
    } else {
      setError("No order found with these details. Please check and try again.");
    }
    setIsLoading(false);
  };

  return (
    <div className="container mx-auto px-4 py-8 sm:py-12 bg-base-100 shadow-lg rounded-lg">
      <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary mb-6 text-center">Track Your Order</h1>
      <div className="max-w-md mx-auto">
        <p className="text-neutral mb-4 text-center text-sm sm:text-base">
          Enter your Order ID and the Email/Phone Number used at checkout to see your order status.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
          <div>
            <label htmlFor="orderId" className="block text-sm font-medium text-gray-700 mb-1">Order ID</label>
            <input 
              type="text" 
              name="orderId" 
              id="orderId" 
              value={orderId}
              onChange={(e) => setOrderId(e.target.value.toUpperCase())}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm" 
              placeholder="e.g., TS12345"
              aria-required="true"
            />
          </div>
          <div>
            <label htmlFor="emailOrPhone" className="block text-sm font-medium text-gray-700 mb-1">Email or Phone Number</label>
            <input 
              type="text" 
              name="emailOrPhone" 
              id="emailOrPhone" 
              value={emailOrPhone}
              onChange={(e) => setEmailOrPhone(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm"
              placeholder="Your email or phone"
              aria-required="true"
            />
          </div>
          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full bg-brand-primary text-white py-2.5 px-4 rounded-md hover:bg-brand-primary-focus focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-opacity-50 transition-colors font-semibold disabled:bg-gray-400"
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Tracking...
              </span>
            ) : "Track Order"}
          </button>
        </form>

        {error && (
          <div className="mt-6 p-3 bg-red-100 border border-red-400 text-red-700 rounded-md text-sm text-center">
            {error}
          </div>
        )}

        {trackingInfo && (
          <div className="mt-8 p-4 sm:p-6 border border-gray-200 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-brand-primary mb-3">Order Status: {trackingInfo.status}</h2>
            <p className="text-sm text-gray-600 mb-1">Last Update: {trackingInfo.lastUpdate}</p>
            {trackingInfo.estimatedDelivery && <p className="text-sm text-gray-600 mb-4">Estimated Delivery: {trackingInfo.estimatedDelivery}</p>}
            <h3 className="text-md font-semibold text-neutral mt-4 mb-2">Tracking History:</h3>
            <ul className="space-y-2 text-sm">
              {trackingInfo.details.map((detail, index) => (
                <li key={index} className="pb-2 border-b border-gray-100 last:border-b-0">
                  {detail}
                </li>
              ))}
            </ul>
          </div>
        )}
        
        <p className="mt-6 text-xs sm:text-sm text-gray-500 text-center">
          Order tracking information is typically available 24-48 hours after your order has shipped. 
          You will also receive updates via email/SMS if provided during checkout.
        </p>
      </div>
    </div>
  );
};
