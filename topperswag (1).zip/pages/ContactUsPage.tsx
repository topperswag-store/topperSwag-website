
import React, { useState } from 'react';
import { MailIcon } from '../components/icons/MailIcon';
import { PhoneIcon } from '../components/icons/PhoneIcon';
import { MapPinIcon } from '../components/icons/MapPinIcon';

export const ContactUsPage: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
        alert("Please fill in all fields.");
        return;
    }
    if (!/\S+@\S+\.\S+/.test(formData.email)) {
        alert("Please enter a valid email address.");
        return;
    }
    // Here you would typically send the data to a backend or email service
    console.log("Form submitted:", formData);
    setIsSubmitted(true);
    setFormData({ name: '', email: '', message: '' }); // Reset form
    // In a real app, you might make an API call here.
    // For now, just simulate success:
    setTimeout(() => setIsSubmitted(false), 5000); // Hide message after 5s
  };

  return (
    <div className="container mx-auto px-4 py-8 sm:py-12 bg-base-100 shadow-lg rounded-lg">
      <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary mb-6 sm:mb-8 text-center">Get In Touch</h1>
      
      {isSubmitted && (
        <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-md text-center">
          Thank you for your message! We'll get back to you soon.
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-8 md:gap-10">
        <div>
          <h2 className="text-xl sm:text-2xl font-semibold text-neutral mb-4">Send us a message</h2>
          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input 
                type="text" 
                name="name" 
                id="name" 
                value={formData.name}
                onChange={handleChange}
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm" 
                placeholder="Your Name"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <input 
                type="email" 
                name="email" 
                id="email" 
                value={formData.email}
                onChange={handleChange}
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm" 
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <textarea 
                name="message" 
                id="message" 
                rows={4} 
                value={formData.message}
                onChange={handleChange}
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm"
                placeholder="Your query or feedback..."
              ></textarea>
            </div>
            <button 
              type="submit" 
              className="w-full bg-brand-primary text-white py-2.5 px-4 rounded-md hover:bg-brand-primary-focus focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-opacity-50 transition-colors font-semibold"
            >
              Send Message
            </button>
          </form>
        </div>
        <div className="space-y-6 text-sm sm:text-base">
          <h2 className="text-xl sm:text-2xl font-semibold text-neutral mb-4">Contact Information</h2>
          <div className="flex items-start space-x-3 p-3 bg-base-200 rounded-md">
            <MailIcon className="w-5 h-5 sm:w-6 sm:h-6 text-brand-primary mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-neutral">Email Us</h3>
              <a href="mailto:topperswag@gmail.com" className="text-brand-accent hover:underline break-all">topperswag@gmail.com</a>
              <p className="text-xs text-gray-500">For all inquiries and support.</p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 bg-base-200 rounded-md">
            <PhoneIcon className="w-5 h-5 sm:w-6 sm:h-6 text-brand-primary mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-neutral">Call Us (Support)</h3>
              <p className="text-gray-600">+91 12345 67890 <span className="text-xs">(Mon-Fri, 10am-6pm IST)</span></p>
              <p className="text-xs text-gray-500">Phone support currently placeholder.</p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 bg-base-200 rounded-md">
            <MapPinIcon className="w-5 h-5 sm:w-6 sm:h-6 text-brand-primary mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-neutral">Our Office <span className="text-xs font-normal">(Not a retail store)</span></h3>
              <p className="text-gray-600">TopperSwag HQ, Student Nagar, Innovation Park, Bangalore, India</p>
              <p className="text-xs text-gray-500">Registered office address. No walk-ins.</p>
            </div>
          </div>
           <p className="text-xs sm:text-sm text-gray-500 mt-4">
            For faster support on product queries or orders, try our WhatsApp button! We're also active on Instagram 
            <a href="https://instagram.com/topper.swag" target="_blank" rel="noopener noreferrer" className="text-brand-accent hover:underline"> @topper.swag</a>.
          </p>
        </div>
      </div>
    </div>
  );
};
