
import React from 'react';

interface OrderConfirmationPageProps {
  orderId: string | null;
  onNavigate: (page: string) => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({ orderId, onNavigate }) => {
  if (!orderId) {
    // This case should ideally not be reached if navigation is handled correctly
    // but good as a fallback.
    return (
      <div className="container mx-auto px-4 py-12 text-center bg-base-100 shadow-lg rounded-lg">
        <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary mb-4">Order Issue</h1>
        <p className="text-neutral mb-6">There was an issue retrieving your order details. Please contact support.</p>
        <button
          onClick={() => onNavigate('home')}
          className="bg-brand-primary text-white font-semibold py-2.5 px-6 rounded-lg hover:bg-brand-primary-focus transition-colors"
        >
          Go to Homepage
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 text-center bg-base-100 shadow-lg rounded-lg">
      <div className="mb-6">
        <svg className="w-16 h-16 sm:w-20 sm:h-20 text-green-500 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
      </div>
      <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary mb-3">Thank You For Your Order!</h1>
      <p className="text-lg text-neutral mb-2">Your order has been placed successfully.</p>
      <p className="text-neutral mb-1">
        Your Order ID is: <strong className="text-brand-primary">{orderId}</strong>
      </p>
      <p className="text-sm text-gray-600 mb-6">
        You will receive an email confirmation shortly with your order details. 
        (This is a simulation, no email will be sent.)
      </p>
      <div className="space-y-3 sm:space-y-0 sm:space-x-4">
        <button
          onClick={() => onNavigate('shop')}
          className="w-full sm:w-auto bg-brand-secondary text-brand-primary font-semibold py-2.5 px-6 rounded-lg hover:bg-brand-secondary-focus transition-colors"
        >
          Continue Shopping
        </button>
        <button
          onClick={() => onNavigate('track-order')}
          className="w-full sm:w-auto bg-gray-200 text-gray-700 font-medium py-2.5 px-6 rounded-lg hover:bg-gray-300 transition-colors"
        >
          Track Your Order
        </button>
      </div>
       <p className="mt-8 text-xs text-gray-500">
        For any questions, contact support at <a href="mailto:topperswag@gmail.com" className="text-brand-accent hover:underline">topperswag@gmail.com</a>.
      </p>
    </div>
  );
};
