
import React from 'react';

interface PolicyPageProps {
  title: string;
  content: string; 
}

export const PolicyPage: React.FC<PolicyPageProps> = ({ title, content }) => {
  // Simple paragraph splitting. For more complex HTML, you'd use dangerouslySetInnerHTML or a markdown parser.
  const paragraphs = content.split('\n\n'); 

  return (
    <div className="container mx-auto px-4 py-8 sm:py-12 bg-base-100 shadow-lg rounded-lg">
      <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary mb-6">{title}</h1>
      <div className="prose prose-sm sm:prose-base max-w-none text-neutral space-y-4 leading-relaxed">
        {paragraphs.map((para, index) => {
            // Basic handling for simple list items indicated by "- " or "* "
            if (para.trim().startsWith('- ') || para.trim().startsWith('* ')) {
                const items = para.split('\n').map(item => item.trim().substring(2));
                return (
                    <ul key={index} className="list-disc pl-5 space-y-1">
                        {items.map((item, itemIndex) => (
                            <li key={itemIndex}>{item}</li>
                        ))}
                    </ul>
                );
            }
            // Basic handling for simple headings indicated by "## "
            if (para.trim().startsWith('## ')) {
                return <h2 key={index} className="text-xl sm:text-2xl font-semibold text-neutral mt-4 mb-2">{para.trim().substring(3)}</h2>
            }
             if (para.trim().startsWith('### ')) {
                return <h3 key={index} className="text-lg sm:text-xl font-semibold text-neutral mt-3 mb-1">{para.trim().substring(4)}</h3>
            }
            return <p key={index}>{para}</p>;
        })}
        
        <p className="mt-8 text-xs text-gray-500">
          This policy was last updated on: {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}.
        </p>
        <p className="text-xs text-gray-500">
          For any questions regarding this policy, please contact us at 
          <a href="mailto:topperswag@gmail.com" className="text-brand-accent hover:underline"> topperswag@gmail.com</a>.
        </p>
      </div>
    </div>
  );
};
