
import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { StarIcon } from '../components/icons/StarIcon'; // Reusing StarIcon
import { PlusIcon } from '../components/icons/PlusIcon';
import { MinusIcon } from '../components/icons/MinusIcon';

interface ProductDetailPageProps {
  product: Product;
  onAddToCart: (product: Product, quantity: number) => void;
  onBuyNow: (product: Product, quantity: number) => void;
  onNavigate: (page: string, slug?: string) => void; // For breadcrumbs or related products
}

const renderStarsDetail = (rating?: number) => {
  if (typeof rating !== 'number' || rating < 0 || rating > 5) {
    return <div className="h-6"></div>; 
  }
  const fullStars = Math.floor(rating);
  const halfStarThreshold = 0.25; 
  const nearlyFullStarThreshold = 0.75;
  
  let effectiveFullStars = fullStars;
  let hasHalfStar = false;
  const decimalPart = rating % 1;

  if (decimalPart >= nearlyFullStarThreshold) effectiveFullStars += 1;
  else if (decimalPart >= halfStarThreshold) hasHalfStar = true;
  
  const emptyStars = 5 - effectiveFullStars - (hasHalfStar ? 1 : 0);
  
  return (
    <div className="flex items-center" aria-label={`Rating: ${rating.toFixed(1)} out of 5 stars`}>
      {[...Array(effectiveFullStars)].map((_, i) => <StarIcon key={`full-${i}`} className="w-6 h-6 text-yellow-400" filled={true} />)}
      {hasHalfStar && <StarIcon key="half" className="w-6 h-6 text-yellow-400" filled={true} isHalf={true} />}
      {[...Array(Math.max(0, emptyStars))].map((_, i) => <StarIcon key={`empty-${i}`} className="w-6 h-6 text-gray-300" filled={false} />)}
      <span className="ml-2 text-base text-gray-600">({rating.toFixed(1)} rating)</span>
    </div>
  );
};

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ product, onAddToCart, onBuyNow, onNavigate }) => {
  const [quantity, setQuantity] = useState(1);
  const isOutOfStock = product.stock !== undefined && product.stock <= 0;

  useEffect(() => {
    // Reset quantity if product changes or becomes out of stock
    setQuantity(1);
  }, [product]);

  const handleIncrement = () => {
    if (product.stock === undefined || quantity < product.stock) {
      setQuantity(prev => prev + 1);
    } else if (product.stock !== undefined) {
      setQuantity(product.stock); // Max out at stock level
    }
  };

  const handleDecrement = () => {
    setQuantity(prev => Math.max(1, prev - 1));
  };

  const handleAddToCart = () => {
    if (!isOutOfStock) {
      onAddToCart(product, quantity);
    }
  };

  const handleBuyNow = () => {
     if (!isOutOfStock) {
      onBuyNow(product, quantity);
    }
  };
  
  const breadcrumbCategory = product.category.toLowerCase().replace(/\s+/g, '-');

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <nav className="text-sm mb-6 text-gray-500" aria-label="Breadcrumb">
        <ol className="list-none p-0 inline-flex space-x-2">
          <li>
            <button onClick={() => onNavigate('home')} className="hover:text-brand-primary">Home</button>
          </li>
          <li><span>/</span></li>
          <li>
            <button onClick={() => onNavigate('shop')} className="hover:text-brand-primary">Shop</button>
          </li>
          <li><span>/</span></li>
          <li>
            <button onClick={() => onNavigate('shop', breadcrumbCategory)} className="hover:text-brand-primary">{product.category}</button>
          </li>
          <li><span>/</span></li>
          <li className="text-gray-700 font-medium" aria-current="page">{product.name}</li>
        </ol>
      </nav>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-start">
        {/* Product Image */}
        <div className="bg-base-100 p-4 rounded-lg shadow-md">
          <img 
            src={product.imageUrl || 'https://via.placeholder.com/800x1000?text=No+Image'} 
            alt={product.name} 
            className="w-full h-auto max-h-[70vh] object-contain rounded-md"
          />
           {isOutOfStock && (
             <div className="mt-4 text-center text-xl font-semibold text-red-600 p-3 bg-red-100 rounded-md">
               Out of Stock
             </div>
           )}
        </div>

        {/* Product Details */}
        <div className="space-y-5">
          <h1 className="text-3xl lg:text-4xl font-bold text-brand-primary">{product.name}</h1>
          <p className="text-lg text-gray-600">{product.category}</p>
          
          {product.rating && <div className="my-2">{renderStarsDetail(product.rating)}</div>}

          <p className="text-3xl lg:text-4xl font-extrabold text-brand-primary">₹{product.price.toFixed(2)}</p>
          
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 my-3">
              {product.tags.map(tag => (
                <span key={tag} className={`text-xs font-semibold px-2.5 py-1 rounded-full
                  ${tag.toLowerCase().includes('special') || tag.toLowerCase().includes('new') 
                    ? 'bg-brand-secondary text-brand-primary' 
                    : tag.toLowerCase().includes('best seller')
                    ? 'bg-yellow-400 text-neutral'
                    : 'bg-brand-accent text-white'}`}>
                  {tag}
                </span>
              ))}
            </div>
          )}

          <div className="prose prose-sm sm:prose-base max-w-none text-neutral leading-relaxed">
            <h3 className="text-lg font-semibold mt-4 mb-2">Description:</h3>
            <p>{product.description}</p>
          </div>
          
          {product.stock !== undefined && !isOutOfStock && product.stock > 0 && product.stock < 10 && (
            <p className="mt-2 text-sm text-red-600 font-semibold">
              Hurry! Only {product.stock} left in stock.
            </p>
          )}

          {!isOutOfStock && (
            <div className="my-6 space-y-4">
              <div className="flex items-center space-x-3">
                <label htmlFor="quantity" className="font-medium text-neutral">Quantity:</label>
                <div className="flex items-center border border-gray-300 rounded">
                  <button 
                    onClick={handleDecrement}
                    className="p-2 text-gray-700 hover:bg-gray-100 disabled:opacity-50"
                    aria-label="Decrease quantity"
                    disabled={quantity <= 1}
                  >
                    <MinusIcon className="w-5 h-5" />
                  </button>
                  <input
                    type="number"
                    id="quantity"
                    name="quantity"
                    value={quantity}
                    onChange={(e) => {
                        let val = parseInt(e.target.value);
                        if (isNaN(val) || val < 1) val = 1;
                        if (product.stock !== undefined && val > product.stock) val = product.stock;
                        setQuantity(val);
                    }}
                    min="1"
                    max={product.stock}
                    className="w-12 text-center text-base font-medium text-neutral border-l border-r border-gray-300 focus:outline-none focus:ring-1 focus:ring-brand-accent"
                    aria-label="Product quantity"
                  />
                  <button 
                    onClick={handleIncrement}
                    className="p-2 text-gray-700 hover:bg-gray-100 disabled:opacity-50"
                    aria-label="Increase quantity"
                    disabled={product.stock !== undefined && quantity >= product.stock}
                  >
                    <PlusIcon className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:space-x-3 space-y-3 sm:space-y-0">
                <button
                  onClick={handleAddToCart}
                  className="w-full sm:flex-1 bg-brand-primary text-white py-3 px-6 rounded-lg text-base font-medium hover:bg-brand-primary-focus focus:outline-none focus:ring-2 focus:ring-brand-primary-focus focus:ring-opacity-50 transition-colors duration-300"
                >
                  Add to Cart
                </button>
                <button
                  onClick={handleBuyNow}
                  className="w-full sm:flex-1 bg-brand-secondary text-brand-primary py-3 px-6 rounded-lg text-base font-semibold hover:bg-brand-secondary-focus focus:outline-none focus:ring-2 focus:ring-brand-secondary-focus focus:ring-opacity-50 transition-colors duration-300"
                >
                  Buy Now
                </button>
              </div>
            </div>
          )}

          {/* Placeholder for related products or reviews */}
          {/* <div className="mt-10 border-t pt-6">
            <h3 className="text-xl font-semibold text-neutral mb-4">You Might Also Like</h3>
            {/* Render related products here *\/}
          </div> */}
        </div>
      </div>
    </div>
  );
};
