
import React from 'react';

export const AboutUsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 sm:py-12 bg-base-100 shadow-lg rounded-lg">
      <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary mb-6 text-center sm:text-left">About TopperSwag</h1>
      <div className="space-y-4 text-neutral text-sm sm:text-base leading-relaxed">
        <p>
          Welcome to TopperSwag, India’s #1 destination for students who want to express themselves with style and confidence! 
          We get it – student life is a vibrant mix of hard work, fun, and self-discovery. That's why we're here to provide 
          you with high-quality, trendy apparel, cool accessories, and motivational gear that resonates with the Gen Z spirit.
        </p>
        <p>
          Our mission is simple: to empower students by offering products that are not just fashionable but also inspire 
          and motivate. From witty quote t-shirts that bring a smile during late-night study sessions to sleek hoodies 
          that make a statement on campus, every item in our collection is curated with you in mind. We believe that 
          what you wear is an extension of your personality and ambitions.
        </p>
        
        <div className="py-4">
            <h2 className="text-xl sm:text-2xl font-semibold text-brand-primary mt-4 sm:mt-6 mb-3">What We Stand For</h2>
            <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-base-200 p-4 rounded-md">
                    <strong className="text-brand-primary block mb-1">Student-Focused:</strong> 
                    <p>Everything we do is for students, by understanding student needs, aspirations, and the occasional all-nighter fuel requirement.</p>
                </div>
                <div className="bg-base-200 p-4 rounded-md">
                    <strong className="text-brand-primary block mb-1">Trendy Designs:</strong> 
                    <p>We keep up with the latest Gen Z trends, memes, and vibes to ensure your swag is always on point and conversation-starting.</p>
                </div>
                <div className="bg-base-200 p-4 rounded-md">
                    <strong className="text-brand-primary block mb-1">Quality Matters:</strong> 
                    <p>Durable materials and prints that last, because your favorite tee should survive many semesters, laundry days, and victory celebrations.</p>
                </div>
                <div className="bg-base-200 p-4 rounded-md">
                    <strong className="text-brand-primary block mb-1">Motivation & Fun:</strong> 
                    <p>We believe in gear that not only looks good but also uplifts, inspires, and adds a bit of fun to the daily grind.</p>
                </div>
            </div>
        </div>
        
        <p className="mt-4 sm:mt-6">
          TopperSwag is more than just a store; it's a community of ambitious, creative, and driven students. We're excited 
          to be part of your journey. Join us, express yourself, and wear your ambition!
        </p>
        <p>
          Got an idea for a design or a product you'd love to see? Drop us a line! We're always listening to our fellow toppers.
        </p>
      </div>
    </div>
  );
};
