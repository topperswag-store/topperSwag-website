
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { ProductList } from './components/ProductList';
import { Footer } from './components/Footer';
import { HeroBanner } from './components/HeroBanner';
import { CategoriesDisplay } from './components/CategoriesDisplay';
import { WhyShopWithUs } from './components/WhyShopWithUs';
import { WhatsAppButton } from './components/WhatsAppButton';
import { AboutUsPage } from './pages/AboutUsPage';
import { ContactUsPage } from './pages/ContactUsPage';
import { TrackOrderPage } from './pages/TrackOrderPage';
import { PolicyPage } from './pages/PolicyPage';
import { AdminPage } from './pages/AdminPage';
import { CartSidebar } from './components/CartSidebar';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage'; // New Import
import { Product, CartItem, ProductFormValues } from './types';
import { MOCK_PRODUCTS } from './constants';


const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [currentProductId, setCurrentProductId] = useState<string | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [lastOrderId, setLastOrderId] = useState<string | null>(null); // For order confirmation

  useEffect(() => {
    setIsLoading(true);
    console.log("Simulating API call to fetch initial products...");
    setTimeout(() => {
      console.log("Products fetched.");
      setProducts(MOCK_PRODUCTS);
      setFilteredProducts(MOCK_PRODUCTS);
      setIsLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    const lowercasedFilter = searchTerm.toLowerCase();
    const filtered = products.filter(product =>
      product.name.toLowerCase().includes(lowercasedFilter) ||
      product.category.toLowerCase().includes(lowercasedFilter) ||
      (product.tags && product.tags.some(tag => tag.toLowerCase().includes(lowercasedFilter)))
    );
    setFilteredProducts(filtered);
    if (searchTerm && currentPage !== 'shop' && currentPage !== 'admin' && !currentPage.startsWith('product/')) {
        setCurrentPage('shop');
        setCurrentProductId(null);
    }
  }, [searchTerm, products, currentPage]);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
  };

  const handleNavigate = (page: string, slug?: string) => {
    if (page === 'product' && slug) {
      setCurrentPage(`product/${slug}`);
      setCurrentProductId(slug);
    } else {
      setCurrentPage(page);
      setCurrentProductId(null);
      if (page === 'shop') {
          if (slug) {
              const categoryFiltered = products.filter(p => p.category.toLowerCase().replace(/\s+/g, '-') === slug);
              setFilteredProducts(categoryFiltered);
          } else {
              setFilteredProducts(products);
          }
          setSearchTerm(''); 
      }
    }
    setIsCartOpen(false);
    window.scrollTo(0, 0);
  };
  
  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  const addToCart = useCallback((product: Product, quantity: number = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevCart, { ...product, quantity }];
    });
    console.log(`${product.name} (Qty: ${quantity}) added to cart.`);
  }, []); 

  const buyNow = useCallback((product: Product, quantity: number = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: Math.max(quantity, item.quantity) } : item
        );
      }
      return [...prevCart, { ...product, quantity }];
    });
    setIsCartOpen(true); 
  }, []);

  const incrementQuantity = useCallback((productId: string) => {
    setCart(prevCart => prevCart.map(item => 
      item.id === productId ? { ...item, quantity: item.quantity + 1 } : item
    ));
  }, []);

  const decrementQuantity = useCallback((productId: string) => {
    setCart(prevCart => prevCart.map(item => 
      item.id === productId && item.quantity > 1 ? { ...item, quantity: item.quantity - 1 } : item
    ).filter(item => item.id !== productId || item.quantity > 0));
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
    // setIsCartOpen(false); // Don't close cart immediately if navigating
  }, []);

  const getCartItemCount = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const getCartSubtotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const handleCheckout = useCallback(() => {
    if (cart.length === 0) {
      alert("Your cart is empty. Please add some products before checking out.");
      return;
    }
    console.log("Simulating API call to /api/orders with cart data:", cart);
    // Simulate API call delay
    setIsLoading(true); // Can use a specific checkout loading state if needed
    setTimeout(() => {
      const mockOrderId = `TS${Date.now()}`;
      console.log("Simulated order creation successful. Order ID:", mockOrderId);
      setLastOrderId(mockOrderId);
      clearCart();
      setIsCartOpen(false); // Close cart sidebar
      handleNavigate('order-confirmation', mockOrderId); // Navigate to order confirmation
      setIsLoading(false);
    }, 1500);
  }, [cart, clearCart]);

  const addProduct = useCallback((newProductData: ProductFormValues) => {
    console.log("Simulating API call to ADD product:", newProductData);
    const newProduct: Product = {
      ...newProductData,
      id: `product_${Date.now().toString()}`, 
      tags: newProductData.tags ? newProductData.tags.split(',').map(tag => tag.trim()).filter(Boolean) : [],
      price: Number(newProductData.price) || 0,
      stock: Number(newProductData.stock) || 0,
      rating: Number(newProductData.rating) || undefined,
    };
    setProducts(prevProducts => {
      const updatedProducts = [newProduct, ...prevProducts];
      if(currentPage === 'admin' || (currentPage === 'shop' && !searchTerm)) {
        setFilteredProducts(updatedProducts);
      }
      return updatedProducts;
    });
  }, [currentPage, searchTerm]);

  const updateProduct = useCallback((updatedProductData: Product) => {
    console.log("Simulating API call to UPDATE product:", updatedProductData);
    setProducts(prevProducts => {
      const updatedProducts = prevProducts.map(p => p.id === updatedProductData.id ? updatedProductData : p);
      if(currentPage === 'admin' || (currentPage === 'shop' && !searchTerm)) {
        setFilteredProducts(updatedProducts);
      }
      return updatedProducts;
    });
  }, [currentPage, searchTerm]);

  const deleteProduct = useCallback((productId: string) => {
    console.log("Simulating API call to DELETE product ID:", productId);
    setProducts(prevProducts => {
      const updatedProducts = prevProducts.filter(p => p.id !== productId);
      if(currentPage === 'admin' || (currentPage === 'shop' && !searchTerm)) {
        setFilteredProducts(updatedProducts);
      }
      return updatedProducts;
    });
  }, [currentPage, searchTerm]);

  const renderPageContent = () => {
    if (isLoading && products.length === 0) {
      return (
        <div className="flex justify-center items-center h-[calc(100vh-200px)]">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-brand-primary"></div>
          <p className="ml-4 text-xl text-neutral">Loading TopperSwag...</p>
        </div>
      );
    }

    if (currentPage.startsWith('product/')) {
      const productId = currentPage.split('/')[1];
      const product = products.find(p => p.id === productId);
      if (!product && !isLoading) {
        return <div className="text-center py-10 min-h-[300px] flex flex-col justify-center items-center">
                <h2 className="text-2xl font-semibold text-neutral mb-4">Product not found</h2>
                <p className="text-gray-500">The product you are looking for does not exist or may have been removed.</p>
                <button onClick={() => handleNavigate('shop')} className="mt-4 bg-brand-primary text-white font-semibold py-2 px-6 rounded-lg hover:bg-brand-primary-focus transition-colors">Go to Shop</button>
            </div>;
      }
      if (!product && isLoading) {
         return (
            <div className="flex justify-center items-center h-[calc(100vh-200px)]">
              <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-brand-primary"></div>
              <p className="ml-4 text-xl text-neutral">Loading Product...</p>
            </div>
          );
      }
      return product ? <ProductDetailPage product={product} onAddToCart={addToCart} onBuyNow={buyNow} onNavigate={handleNavigate} /> : null;
    }

    if (currentPage.startsWith('order-confirmation')) {
      const orderIdFromSlug = currentPage.split('/')[1];
      return <OrderConfirmationPage orderId={orderIdFromSlug || lastOrderId} onNavigate={handleNavigate} />;
    }


    switch (currentPage) {
      case 'home':
        return (
          <>
            <HeroBanner onShopNow={() => handleNavigate('shop')} />
            <CategoriesDisplay onNavigate={handleNavigate} />
            <section className="py-12 bg-base-100">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center text-neutral mb-8">Best Sellers</h2>
                <ProductList 
                  products={products.filter(p => p.tags?.includes('Best Seller') || (p.rating && p.rating >= 4.7)).slice(0,4)} 
                  onAddToCart={addToCart}
                  onBuyNow={buyNow}
                  onProductClick={(productId) => handleNavigate('product', productId)}
                />
              </div>
            </section>
            <WhyShopWithUs />
            <section className="py-12 bg-base-200">
                <div className="container mx-auto px-4 text-center">
                    <h2 className="text-3xl font-bold text-neutral mb-4">Student Testimonials</h2>
                    <p className="text-gray-600 mb-6">(Coming Soon! Share your TopperSwag story with us!)</p>
                    <h2 className="text-3xl font-bold text-neutral mt-10 mb-4">Our Instagram Feed</h2>
                    <p className="text-gray-600 mb-6">(To be linked with @topper.swag - placeholder)</p>
                </div>
            </section>
          </>
        );
      case 'shop':
        return (
          <section className="py-8">
            <h2 className="text-3xl font-bold text-center text-neutral mb-8">
              {searchTerm ? `Search Results for "${searchTerm}"` : 'All Products'}
            </h2>
            {filteredProducts.length > 0 ? (
              <ProductList 
                products={filteredProducts} 
                onAddToCart={addToCart}
                onBuyNow={buyNow}
                onProductClick={(productId) => handleNavigate('product', productId)}
              />
            ) : (
              <div className="text-center py-10 min-h-[300px] flex flex-col justify-center items-center">
                <h2 className="text-2xl font-semibold text-neutral mb-4">No products found</h2>
                <p className="text-gray-500">Try adjusting your search term or check back later!</p>
              </div>
            )}
          </section>
        );
      case 'about':
        return <AboutUsPage />;
      case 'contact':
        return <ContactUsPage />;
      case 'track-order':
        return <TrackOrderPage />;
      case 'admin': 
        return <AdminPage 
                  products={products} 
                  onAddProduct={addProduct} 
                  onUpdateProduct={updateProduct} 
                  onDeleteProduct={deleteProduct} 
                />;
      case 'privacy-policy':
        return <PolicyPage 
                  title="Privacy Policy" 
                  content={`Your privacy is critically important to us at TopperSwag. This Privacy Policy document outlines the types of personal information that is received and collected and how it is used.\n\nIf you require any more information or have any questions about our privacy policy, please feel free to contact us by email at topperswag@gmail.com.\n\nLog Files: Like many other Web sites, TopperSwag makes use of log files. These files merely logs visitors to the site – usually a standard procedure for hosting companies and a part of hosting services’s analytics. The information inside the log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date/time stamp, referring/exit pages, and possibly the number of clicks. This information is used to analyze trends, administer the site, track user’s movement around the site, and gather demographic information. IP addresses, and other such information are not linked to any information that is personally identifiable.\n\nCookies and Web Beacons: TopperSwag uses cookies to store information about visitors’ preferences, to record user-specific information on which pages the site visitor accesses or visits, and to personalize or customize our web page content based upon visitors’ browser type or other information that the visitor sends via their browser.\n\nThird-Party Privacy Policies: You should consult the respective privacy policies of these third-party ad servers for more detailed information on their practices as well as for instructions about how to opt-out of certain practices. TopperSwag's privacy policy does not apply to, and we cannot control the activities of, such other advertisers or web sites.`} 
                />;
      case 'terms-conditions':
        return <PolicyPage 
                  title="Terms & Conditions" 
                  content={`Welcome to TopperSwag! These terms and conditions outline the rules and regulations for the use of TopperSwag's Website, located at yourwebsite.com (once deployed).\n\nBy accessing this website we assume you accept these terms and conditions. Do not continue to use TopperSwag if you do not agree to take all of the terms and conditions stated on this page.\n\nThe following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: “Client”, “You” and “Your” refers to you, the person log on this website and compliant to the Company’s terms and conditions. “The Company”, “Ourselves”, “We”, “Our” and “Us”, refers to our Company. “Party”, “Parties”, or “Us”, refers to both the Client and ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of provision of the Company’s stated services, in accordance with and subject to, prevailing law of India. Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they, are taken as interchangeable and therefore as referring to same.`} 
                />;
      case 'refund-policy':
        return <PolicyPage 
                  title="Return & Refund Policy" 
                  content={`Thank you for shopping at TopperSwag!\n\nWe offer refund and/or exchange within the first 15 days of your purchase, if 15 days have passed since your purchase, you will not be offered a refund and/or exchange of any kind.\n\nEligibility for Refunds and Exchanges: Your item must be unused and in the same condition that you received it. The item must be in the original packaging. To complete your return, we require a receipt or proof of purchase. Only regular priced items may be refunded, sale items cannot be refunded.\n\nExchanges (if applicable): We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at topperswag@gmail.com.\n\nShipping: You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.`} 
                />;
      default:
        return <div className="text-center py-10 min-h-[300px] flex flex-col justify-center items-center">
                <h2 className="text-4xl font-bold text-brand-primary mb-4">404</h2>
                <p className="text-xl text-neutral mb-2">Oops! Page Not Found.</p>
                <p className="text-gray-500 mb-6">The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
                <button
                    onClick={() => handleNavigate('home')}
                    className="bg-brand-primary text-white font-semibold py-2 px-6 rounded-lg hover:bg-brand-primary-focus transition-colors"
                >
                    Go to Homepage
                </button>
            </div>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-base-200 font-sans text-neutral">
      <Header 
        onSearch={handleSearch} 
        cartItemCount={getCartItemCount()}
        onNavigate={handleNavigate} 
        currentPage={currentPage}
        onToggleCart={toggleCart}
      />
      <CartSidebar
        isOpen={isCartOpen}
        onClose={toggleCart}
        cartItems={cart}
        onIncrement={incrementQuantity}
        onDecrement={decrementQuantity}
        onRemove={removeFromCart}
        onClearCart={clearCart}
        subtotal={getCartSubtotal()}
        onNavigate={handleNavigate}
        onCheckout={handleCheckout} // Pass handleCheckout
      />
      <main className="flex-grow container mx-auto px-4 py-8">
        {renderPageContent()}
      </main>
      <Footer onNavigate={handleNavigate} />
      <WhatsAppButton />
    </div>
  );
};

export default App;
