export interface Product {
  id: string;
  name: string;
  price: number; // Prices will be in INR
  description: string;
  imageUrl: string;
  category: string; // e.g., 'T-Shirts', 'Hoodies', 'Stationery', 'Accessories'
  rating?: number; // Optional rating
  stock?: number; // Optional stock count
  tags?: string[]; // For "Student Special", "Best Seller", "New Arrival", "Limited Edition" etc.
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Category {
  name: string;
  imageUrl: string;
  slug: string; // for URL navigation or filtering
}

// For product creation/editing form. Values might be strings initially from form.
export interface ProductFormValues {
  id?: string; // Optional: only present when editing
  name: string;
  description: string;
  price: string; // Handle as string from form, convert to number on save
  imageUrl: string;
  category: string;
  stock: string; // Handle as string from form, convert to number on save
  rating: string; // Handle as string from form, convert to number on save
  tags: string; // Comma-separated string
}